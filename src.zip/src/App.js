import "./App.css";
import Home from "./pages/Home";
import Main from "./pages/Main";

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
